<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>Course Enrollment Management</title>
    <link rel="stylesheet" type="text/css"
          href="../main.css">
</head>

<!-- the body section -->
<body>
<header>
    <h1>Course Enrollment Management</h1>
    <p>Course Enrollment Management System for Auburn University at Montgomery</p>
    <nav>
        <ul>
            <li><a href="/peoject-backend-final/">Home</a></li>
        </ul>
    </nav>
</header>
