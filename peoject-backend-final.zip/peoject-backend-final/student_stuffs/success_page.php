<?php if(isset($message)):?>

    <?php echo $message;?><br><br>

<?php endif; ?>

