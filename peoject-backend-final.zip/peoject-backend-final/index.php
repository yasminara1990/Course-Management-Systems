<?php include 'view/header.php'; ?>
<main>
    <nav>    
        <h2>Here to start! </h2>
        <ul>
            <li><a href="student_stuffs/login.php">Login</a></li>
            <li><a href="student_stuffs/registration.php">Register</a></li>
        </ul>

    </nav>
</main>
<?php include 'view/footer.php'; ?>